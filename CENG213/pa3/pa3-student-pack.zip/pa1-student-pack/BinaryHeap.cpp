#include "BinaryHeap.h"

BinaryHeap::BinaryHeap()
{
    // TODO: or not
}


bool BinaryHeap::Add(int uniqueId, double weight)
{
    // TODO:
}

bool BinaryHeap::PopHeap(int& outUniqueId, double& outWeight)
{
    // TODO:
}

bool BinaryHeap::ChangePriority(int uniqueId, double newWeight)
{
    // TODO:
}

int BinaryHeap::HeapSize() const
{
    // TODO:
}